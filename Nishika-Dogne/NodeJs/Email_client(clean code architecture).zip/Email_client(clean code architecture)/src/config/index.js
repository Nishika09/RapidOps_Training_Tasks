const config = require('./backend-config/development');
module.exports=config;