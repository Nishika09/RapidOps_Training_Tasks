const users = require('./users');
const emailFolder=require('./email-folders');

module.exports = Object.freeze({
    users,
    emailFolder
})